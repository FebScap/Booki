# Développeur Web P2 : Transformez une maquette en site web avec HTML et CSS

**Version hébergée**: https://febscap.github.io/Booki/

**Presentation**: https://febscap.github.io/Booki/presentation.html

**Code source**: https://github.com/FebScap/Booki